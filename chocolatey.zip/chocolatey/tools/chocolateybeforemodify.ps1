﻿# This script will back up previously installed versions of LCP prior to updating the CWEB Web Application

#If ((Test-Path E:)){
#
#	$backupFolder = 'E:\backups'
#
#}Else{
#
#	$backupFolder = 'C:\backups'
#
#	}

# remove previous backups if they exist
#Remove-Item $backupFolder -Recurse -ErrorAction Ignore

# stop the IIS server while app code is backed up
#Invoke-Command -ScriptBlock {iisreset /STOP}

# create folder for CWEB backup and copy CWEB contents there
#New-Item -ItemType directory -Path "$backupFolder\CWEB"
#Get-ChildItem -Path "$Env:systemdrive\inetpub\wwwroot\webroot" -Recurse | Move-Item -Destination "$backupFolder\CWEB"

# remove previous ATMS code folders
