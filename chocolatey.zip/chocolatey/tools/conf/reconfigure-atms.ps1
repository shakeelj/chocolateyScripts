# ***************************************************************************
# ***************************************************************************
# Variables

Param ( [string]$serverString )

# Locations of props files for Services
write-host "Locating CHART Services"
#$chartInstalled = (get-childitem -path HKLM:\SYSTEM\CurrentControlSet\Services -recurse -ErrorAction SilentlyContinue | Where-Object {$_.Name -like "*CHART*"} | select -first 1)
$chartInstalled = (get-childitem -path HKLM:\SYSTEM\CurrentControlSet\Services -ErrorAction SilentlyContinue | Where-Object {$_.Name -like "*CHART*"} | select -first 1)

if ($chartInstalled) {
	write-host "found chart services"
	$chartInstalled = $chartInstalled.Name.Replace("HKEY_LOCAL_MACHINE","")
	$chartInstalled = "HKLM:" + $chartInstalled
	$chartHome = (Get-ItemProperty -Path $chartInstalled -Name ImagePath).ImagePath
	$chartDrive = Split-Path -Path $chartHome -Qualifier
	write-host $chartDrive
	} elseif (Test-Path -Path "e:") {
		$chartDrive = "e:"
		} elseif (Test-Path -Path "c:") {
			$chartDrive = "c:"
			}
	
$servicePath = "$chartDrive\Program Files\"
#$servicePath = "C:\Program Files\"

$releaseDir = Get-ChildItem "$toolsDir\app_code\$serverConf" -Recurse | Where-Object { $_.PSIsContainer -and $_.Name.StartsWith("CHART")}
$serviceFolder = $servicePath + $releaseDir
$ext = 'props'

# ***************************************************************************
# ***************************************************************************

function replaceText {

	param( [string]$propsFile,
			[string]$placeHolder,
			[string]$value)
			
	(Get-Content $propsFile).replace($placeHolder, $value) | Set-Content $propsFile

}

# ***************************************************************************
# REWRITE THIS AS A CASE STATEMENT TO ERROR IF NO TOMCAT
# get location of tomcat install
# ***************************************************************************

write-host "Locating Tomcat home"
$tomcat9Key = 'HKLM:\SOFTWARE\Apache Software Foundation\Tomcat\9.0\Tomcat9'
$tomcat9Installed = (test-path $tomcat9Key)

if ($tomcat9Installed) {
	$tomcat9Home = (Get-ItemProperty -Path "$tomcat9Key" -Name InstallPath).InstallPath
	$webappDir = $tomcat9Home + "\webapps"
	$webappRequests = $tomcat9Home + "\webapps\CHARTExportClientService\WEB-INF\requests"
	}

# ***************************************************************************
# ***************************************************************************

Write-Host "UPDATING ATMS CONFIG"
	
if(!$serverString){

    Write-Host "no server string set"

    exit 1

	} else {

	# set config files to update
	$serviceProps = Get-ChildItem -Path $serviceFolder -Filter *.$ext -Recurse | ForEach-Object {$_.FullName}
	$serviceCmd = Get-ChildItem -Path $serviceFolder -Filter *.cmd -Recurse | ForEach-Object {$_.FullName}
	$webappProps = Get-ChildItem -Path $webappDir -Filter *.$ext -Recurse | ForEach-Object {$_.FullName}
	
	$configFiles = $serviceProps + $serviceCmd + $webappProps
	
	if ($serverConf -ne "swgi") {

		$webappRequestXML = Get-ChildItem -Path $webappRequests -Filter *.xml -Recurse | ForEach-Object {$_.FullName}
		$configFiles = $configFiles + $webappRequestXML

		}

	# get values to use from props file
	$fileContents = get-content $toolsDir/conf/$serverString.properties

	$properties = @{}
	
	foreach($line in $fileContents) {
	$words = $line.Split('=',2)
	$properties.add($words[0].Trim(), $words[1].Trim())
	}
	
	# set parameters (array of arrays)

	$APPHOSTNAME = "APPTEMPLATE",$properties.APPHOSTNAME
	$EXPHOSTNAME = "EXPTEMPLATE",$properties.EXPHOSTNAME
	$SWGIHOSTNAME = "SWGITEMPLATE",$properties.SWGIHOSTNAME
	$ESHOSTNAME = "ESTEMPLATE",$properties.ESHOSTNAME
	$DB1_HOST = "DB1_HOST",$properties.DB1_HOST
	$MAP_HOST_1 = "MAP_HOST_1",$properties.MAP_HOST_1
	$MAP_HOST_2 = "MAP_HOST_2",$properties.MAP_HOST_2
	$CWEB_HOST = "CWEB_HOST",$properties.CWEB_HOST
	$LCP_DATA_EXPORTER_HOST = "LCP_DATA_EXPORTER_HOST",$properties.LCP_DATA_EXPORTER_HOST
	$CHARTWEB_URL = "CHARTWEB_URL",$properties.CHARTWEB_URL
	$LCP_URL = "LCP_URL",$properties.LCP_URL
	$EORS_V2_URL = "EORS_V2_URL",$properties.EORS_V2_URL
	$TRADER_HOST = "TRADER_HOST",$properties.TRADER_HOST
	$PDB_HOST = "PDB_HOST",$properties.PDB_HOST

	$params = $APPHOSTNAME,$EXPHOSTNAME,$SWGIHOSTNAME,$ESHOSTNAME,$DB1_HOST,$MAP_HOST_1,$MAP_HOST_2,$CWEB_HOST,$LCP_DATA_EXPORTER_HOST,$CHARTWEB_URL,$LCP_URL,$EORS_V2_URL,$TRADER_HOST,$PDB_HOST
	
	# call update function for each file
	Foreach ($file in $configFiles) {
		
		Foreach ($set in $params) {
			replaceText -propsFile $file -placeHolder $set[0] -value $set[1]
		}

	}

	# ***************************************************************************
	# ***************************************************************************
	# Clear the trader table

	if ($serverConf -eq "app") {

		write-host "Clearing the Trader Table"
		$traderFile = Get-Content "$serviceFolder\bin\TradingService\clean_trader.cmd"
		$skipCommand = "set SKIP_DELETE_TRADER_DATA_CONFIRMATION=true"
		Set-Content "$serviceFolder\bin\TradingService\clean_trader.cmd" -value $skipCommand, $traderFile

		start-process -FilePath "$serviceFolder\bin\TradingService\clean_trader.cmd" -WorkingDirectory "$serviceFolder\bin\TradingService" -Wait -NoNewWindow

		(Get-Content "$serviceFolder\bin\TradingService\clean_trader.cmd").Replace('set SKIP_DELETE_TRADER_DATA_CONFIRMATION=true', 'REM set SKIP_DELETE_TRADER_DATA_CONFIRMATION=true') | Set-Content "$serviceFolder\bin\TradingService\clean_trader.cmd"

	}
	
	# ***************************************************************************
	# ***************************************************************************

}

write-host ""
write-host "The ATMS configuration has been updated"
write-host ""