# Clean up invalid path entries
$pathEntries = $env:PATH

$pathArray = @($pathEntries.split(';'))

# Create a new PATH string with invalid entries removed
foreach ($p in $pathArray) {
	if ($p -inotmatch "mfleming2") {
	
		$updatedPath += $p + ';'
		
		}
		
	}

$updatedPath = $updatedPath.TrimEnd(';')
$updatedPath = $updatedPath.TrimEnd('"')

# Update the PATH with the cleaned up PATH
$env:PATH = $updatedPath