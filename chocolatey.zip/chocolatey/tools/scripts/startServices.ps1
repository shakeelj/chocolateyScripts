# ***************************************************************************
# ***************************************************************************
# Variables

$tomcatService = "Tomcat9"

# ***************************************************************************
# ***************************************************************************


# start CHART services for current version that are set to start as Automatic
$serviceNames = (Get-WMIObject Win32_Service -Filter "Name LIKE '%CHART%'" | Select -ExpandProperty Name)

foreach ($service in $serviceNames) {
	$serviceObject = Get-WmiObject -Class Win32_Service -Filter "Name=`'$service`'"
	
	if (($service -like "*$env:ChocolateyPackageVersion*") -And ($serviceObject.startmode -eq "Auto")) {
		write-host "Starting Service $service"
		start-service $service
		}
	}

# start Tomcat service
write-host "Starting Service $tomcatService"
start-service $tomcatService