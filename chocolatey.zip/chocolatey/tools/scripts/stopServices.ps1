$ErrorActionPreference = 'SilentlyContinue';

# ***************************************************************************
# ***************************************************************************
# Variables

$tomcatService = "Tomcat9"

# ***************************************************************************
# ***************************************************************************

# stop and disable ALL existing CHART services
$serviceNames = (Get-WMIObject Win32_Service -Filter "Name LIKE '%CHART%'" | Select -ExpandProperty Name)

if ($serviceNames) {
	[array]::Reverse($serviceNames)

	foreach ($service in $serviceNames) {
		if ($service -like "*$env:ChocolateyPackageVersion*") {
			write-host "versions match: removing service $service"
			stop-service $service
			# delete service
			$serviceObject = Get-WmiObject -Class Win32_Service -Filter "Name=`'$service`'"
			$serviceObject.delete()
			} else {
				write-host "Disabling $service"
				stop-service $service
				set-service $service -startuptype disabled
			}
		}
}

# stop Tomcat service
write-host "Stopping $tomcatService"

$arrService = Get-Service -Name $tomcatService
write-host $arrService.status

while ($arrService.Status -ne 'Stopped')
{

	Stop-Service $tomcatService
    Start-Sleep -seconds 5
    $arrService.Refresh()
    if ($arrService.Status -eq 'Stopped')
    {
        Write-Host "$tomcatService is now stopped"
    }

}