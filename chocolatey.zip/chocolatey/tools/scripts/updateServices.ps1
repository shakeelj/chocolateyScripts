# ***************************************************************************
# ***************************************************************************
# Variables

write-host "Locating CHART Services"
#$chartInstalled = (get-childitem -path HKLM:\SYSTEM\CurrentControlSet\Services -recurse -ErrorAction SilentlyContinue | Where-Object {$_.Name -like "*CHART*"} | select -first 1)
$chartInstalled = (get-childitem -path HKLM:\SYSTEM\CurrentControlSet\Services -ErrorAction SilentlyContinue | Where-Object {$_.Name -like "*CHART*"} | select -first 1)

if ($chartInstalled) {
	write-host "found chart services"
	$chartInstalled = $chartInstalled.Name.Replace("HKEY_LOCAL_MACHINE","")
	$chartInstalled = "HKLM:" + $chartInstalled
	$chartHome = (Get-ItemProperty -Path $chartInstalled -Name ImagePath).ImagePath
	$chartDrive = Split-Path -Path $chartHome -Qualifier
	write-host $chartDrive
	} elseif (Test-Path -Path "e:") {
		$chartDrive = "e:"
		} elseif (Test-Path -Path "c:") {
			$chartDrive = "c:"
			}
	
$servicePath = "$chartDrive\Program Files\"
$releaseDir = Get-ChildItem "$toolsDir\app_code\$serverConf" -Recurse | Where-Object { $_.PSIsContainer -and $_.Name.StartsWith("CHART")}
$serviceFolder = $servicePath + $releaseDir
$tempFolder = $servicePath + "\TEMP"
$dateStr = "_$((Get-Date).ToString('yyyyMMddhhmm'))"
$archiveFolderName = "$releaseDir" + "$dateStr"
$serviceInstallDir = $toolsDir + "\app_code\" + $serverConf + "\" + $releaseDir

if ($serverConf -eq 'app') {

	$javacommFolder = $toolsDir + "\app_code\" + $serverConf + "\installer_files\javacomm"

}

# ***************************************************************************
# ***************************************************************************

# ***************************************************************************
# ***************************************************************************

function replaceText {

	param( [string]$propsFile,
			[string]$placeHolder,
			[string]$value)
			
	(Get-Content $propsFile).replace($placeHolder, $value) | Set-Content $propsFile

}

# ***************************************************************************
# ***************************************************************************

write-host "Updating Services for ATMS R$env:ChocolateyPackageVersion"

# archive existing ID files for the current release
if (Test-Path $serviceFolder) {
	write-host "Archiving $serviceFolder"
	
	if (Test-Path $tempFolder) {
	write-host "Temp Folder found - removing $tempFolder"
	Remove-Item -Recurse -Force "$tempFolder"
	}
	
	# gather ID files into temp folder
	$subFolders = (Get-ChildItem "$serviceFolder\bin" -Directory)
	foreach ($folder in $subFolders) {
		$a = $serviceFolder + "\bin\" + $folder
		# check for ID file and copy it to TEMP if found
		$idFile = Get-ChildItem -Path "$a\*" -Include *.id
		if ($idFile) {
			write-host "ID file found for $folder"
			New-Item -ItemType Directory -Path "$tempFolder\$env:ChocolateyPackageVersion\$folder"
			copy-item $idFile -Destination "$tempFolder\$env:ChocolateyPackageVersion\$folder"
			}
		}
		
	if ($stringName -eq 'neptune') {
		remove-item -path $serviceFolder -force -recurse
		} else {
			rename-item -path $serviceFolder -newName $archiveFolderName
			}
	}


# REWRITE THIS AS A CASE STATEMENT TO ERROR IF NO JAVA
write-host "Updating System Path for CHART Services"

# get 64-bit JRE path
$jre64Key = 'HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment'
$jre64Installed = (test-path $jre64Key)

if ($jre64Installed) {
	$jre64Ver = (Get-ItemProperty -Path $jre64Key -Name CurrentVersion).CurrentVersion
	$jre64Home = (Get-ItemProperty -Path "$jre64Key\$jre64Ver" -Name JavaHome).JavaHome
	}
	
# Assign a value to jre32Home - this is required in cases where the registry does not show 32-bit java installs
if ($jre64Home) {
	$jre32Home = $jre64Home -replace "Program Files", "Program Files (x86)"
	}

# get 32-bit JRE path - if 32bit JRE is found install Javacomm files
$jre32Key = 'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment'
$jre32Installed = (test-path $jre32Key)

if ($jre32Installed) {
	write-host "32bit Java Found"
	$jre32Ver = (Get-ItemProperty -Path $jre32Key -Name CurrentVersion).CurrentVersion
	
	# in some cases the JavaHome value is stored in $jre32Key and $jre32Key\$jre32Ver is not created
	if (test-path "$jre32Key\$jre32Ver") {
		$jre32Home = (Get-ItemProperty -Path "$jre32Key\$jre32Ver" -Name JavaHome).JavaHome
		} elseif ($jre64Home) {
			$jre32Home = $jre64Home -replace "Program Files", "Program Files (x86)"
			}
	
	if (!(test-path $jre32Home)) {
		write-host "The 32-bit JRE directory specified in the registry does not exist. Javacomm files were not copied."
	} elseif ($serverConf -eq 'app') {
		write-host "Copying javacomm files to the JRE directory"
		
		if (!(Test-Path "$jre32Home\bin")) {new-item -path "$jre32Home" -name "bin" -type directory}
		if (!(Test-Path "$jre32Home\lib\ext")) {new-item -path "$jre32Home" -name "lib\ext" -type directory}

		if (Test-Path $javacommFolder) {copy-item -path "$javacommFolder\javax.comm.properties" -destination "$jre32Home\lib"}

		if (Test-Path $javacommFolder) {copy-item -path "$javacommFolder\win32com.dll" -destination "$jre32Home\bin"}
   
		if (Test-Path $javacommFolder) {copy-item -path "$javacommFolder\comm.jar" -destination "$jre32Home\lib\ext" -recurse}
		}
	
	}

# update system path to support CHART services
if ($env:JAVA_HOME) {
	$javaHome = $env:JAVA_HOME
	} elseif ($jre32Installed) {
		$javaHome = $jre32Home
		} elseif ($jre32Home) {
			$javaHome = $jre32Home
			} elseif ($jre64Installed) {
				$javaHome = $jre64Home
				}
		
$systemPath = $env:PATH

$systemPath = $systemPath.replace("$javaHome\bin\client;","")
$systemPath = $systemPath.replace("$javaHome\bin;","")
$systemPath = $systemPath.replace(";$javaHome\bin\client","")
$systemPath = $systemPath.replace(";$javaHome\bin","")

$systemPath = "$javaHome\bin;$javaHome\bin\client;$systemPath"
[System.Environment]::SetEnvironmentVariable('PATH', "$systemPath", [System.EnvironmentVariableTarget]::Machine)

# copy service files
write-host "Copying Service Files to Host"
Copy-Item $serviceInstallDir\ -Destination $serviceFolder -Recurse

# ***************************************************************************
# ***************************************************************************
# register services

#if (!(Test-Path "e:\")) {
#	replaceText -propsFile "$serviceFolder\bin\setEnvVars.cmd" -placeHolder "e:" -value "c:"
#	}
	
replaceText -propsFile "$serviceFolder\bin\setEnvVars.cmd" -placeHolder "e:" -value "$chartDrive"

start-process -FilePath "$serviceFolder\bin\register_services.cmd" -WorkingDirectory "$serviceFolder\bin" -Wait -NoNewWindow

# ***************************************************************************
# ***************************************************************************

# reinstall archived ID files
if (test-path $tempFolder\$env:ChocolateyPackageVersion) {
	write-host "Reinstalling archived ID files"
	copy-item $tempFolder\$env:ChocolateyPackageVersion\* $serviceFolder\bin -force -recurse
	}
	
# The ES server has specific service configurations, run this if you are on ES
if ($serverConf -eq 'es') {
	write-host "Configuring Services for ES"
	
	start-process -FilePath "$serviceFolder\bin\SetAllServicesForES.cmd" -WorkingDirectory "$serviceFolder\bin" -Wait -NoNewWindow
	}

# The DMSFactory.id file is a configured item because it is used in the database, so we need a known ID.
if ($serverConf -eq 'app') {
	write-host "Reinstalling DMSFactory.id"
	if ("$serviceInstallDir\bin\DMSService\DMSFactory.id") {
		write-host "Copying configured DMSFactory.id file with known ID"
		Copy-Item "$serviceInstallDir\bin\DMSService\DMSFactory.id" -Destination "$serviceFolder\bin\DMSService"
		}
}
		
if (test-path $tempFolder) {
	write-host "Removing temp folder"
	Remove-Item -Recurse -Force "$tempFolder"
	}
